package com.example.demo.model.dto;

public class CpuBaselineResponse {
    private String hostname;
    private double mean;
    private double std;
    private double dynamicThreshold; // mean + 2 * std
    // 生成Getter和Setter

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public double getMean() {
        return mean;
    }

    public void setMean(double mean) {
        this.mean = mean;
    }

    public double getStd() {
        return std;
    }

    public void setStd(double std) {
        this.std = std;
    }

    public double getDynamicThreshold() {
        return dynamicThreshold;
    }

    public void setDynamicThreshold(double dynamicThreshold) {
        this.dynamicThreshold = dynamicThreshold;
    }

}
