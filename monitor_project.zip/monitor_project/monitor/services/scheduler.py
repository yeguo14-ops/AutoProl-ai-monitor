# monitor/scheduler.py
"""
调度器模块
功能：协调各个模块，执行主循环
"""

import time
import os
from logger_config import setup_logger
from dotenv import load_dotenv
from .collector import collect_system_metrics
from ..repo.storage import save_to_mysql_with_fallback, save_to_file, retry_cached_data
from .alerter import check_and_alert
from ..repo.ai_java_client import log_ai_service_url_at_startup

load_dotenv()
logger = setup_logger(__name__)

def run_one_collection_cycle():
    """执行一轮完整的数据采集流程"""
    logger.info(f"开始新一轮采集: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
 # 1. 采集数据 (已带重试)
    data = collect_system_metrics(max_retries=1, retry_delay=2)
    if data is None:
        logger.error("数据采集失败，跳过本轮")
        return {'采集': False, '存储': False, '告警': False}
    
    # 2. 存储到MySQL (带降级)
    storage_success = save_to_mysql_with_fallback(data)
    
    # 3. 写入本地文件 (基础备份，尽力而为)
    try:
        save_to_file(data)
    except Exception as e:
        logger.error(f"写入本地日志文件失败 (非关键): {e}")
    
    # 4. 检查并发送告警 (已带重试和防刷)
    alert_sent = False
    try:
        alert_sent = check_and_alert(data)
    except Exception as e:
        logger.error(f"告警检查过程出错: {e}", exc_info=True)
    
    result = {'采集': True, '存储': storage_success, '告警': alert_sent}
    logger.debug(f"本轮采集完成。结果: {result}")
    return result

def main_loop():
    """主循环函数"""
    log_ai_service_url_at_startup()
    logger.info("🚀 监控数据采集模块启动")
    interval = int(os.getenv('COLLECT_INTERVAL', 10))
    logger.info(f"采集间隔: {interval}秒")
    
    # 启动时，先尝试重试之前缓存的数据
    logger.info("启动时尝试重试缓存数据...")
    retry_success, retry_fail = retry_cached_data()
    if retry_success > 0:
        logger.info(f"启动重试完成: 成功 {retry_success} 条")
    
    error_streak = 0  # 连续错误次数
    MAX_ERROR_STREAK = 3
    
    while True:
        try:
            result = run_one_collection_cycle()
            
            # 如果整个周期都失败了，增加错误计数
            if not any(result.values()):  # 所有结果都为False
                error_streak += 1
            else:
                error_streak = 0  # 有成功部分，重置
            
            # 根据错误连续次数，动态调整等待时间
            if error_streak >= MAX_ERROR_STREAK:
                wait_time = min(interval * 5, 300)  # 最大等待5分钟
                logger.error(f"连续失败{error_streak}次，延长等待至{wait_time}秒")
            else:
                wait_time = interval
            
            logger.info(f"本轮结束，{wait_time}秒后继续...")
            time.sleep(wait_time)
            
        except KeyboardInterrupt:
            logger.info("🛑 监控系统被用户中断")
            break
        except Exception as e:
            error_streak += 1
            logger.error(f"⛈️  主循环发生未捕获的严重错误: {e}", exc_info=True)
            time.sleep(min(60, interval * 3))  # 出错后等待
