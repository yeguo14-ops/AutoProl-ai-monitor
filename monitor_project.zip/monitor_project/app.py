﻿"""
监控系统Web界面
"""
from logger_config import setup_logger
from flask import Flask, render_template, jsonify, request
import pymysql
import sys
import os
from dotenv import load_dotenv
from monitor.repo.hostname import validate_report_hostname

load_dotenv()

sys.dont_write_bytecode = False
sys.pycache_prefix = "./cache/"
logger = setup_logger(__name__)

app = Flask(__name__)

DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', 'AutoPA@2026'),
    'database': os.getenv('DB_NAME', 'monitor'),
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

@app.route('/api/hosts')
def api_hosts():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    if per_page > 100:
        per_page = 100
    offset = (page - 1) * per_page

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(DISTINCT host_name) AS total FROM server_status")
    total = cursor.fetchone()['total']

    cursor.execute("""
        SELECT host_name, MAX(collect_time) AS last_seen
        FROM server_status
        GROUP BY host_name
        ORDER BY host_name
        LIMIT %s OFFSET %s
    """, (per_page, offset))
    hosts = cursor.fetchall()
    cursor.close()
    conn.close()

    host_list = []
    for h in hosts:
        host_list.append({
            'name': h['host_name'],
            'last_seen': h['last_seen'].isoformat() if h['last_seen'] else None
        })

    return jsonify({
        'total': total,
        'page': page,
        'per_page': per_page,
        'hosts': host_list
    })

@app.route('/api/metrics')
def api_metrics():
    host = request.args.get('host')
    if not host:
        return jsonify({'error': 'host parameter required'}), 400
    limit = request.args.get('limit', 100, type=int)
    if limit > 500:
        limit = 500

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT cpu_percent, memory_percent, disk_percent, collect_time
        FROM server_status
        WHERE host_name = %s
        ORDER BY collect_time DESC
        LIMIT %s
    """, (host, limit))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    data = []
    for row in reversed(rows):
        data.append({
            'time': row['collect_time'].isoformat(),
            'cpu': round(row['cpu_percent'], 1),
            'mem': round(row['memory_percent'], 1),
            'disk': round(row['disk_percent'], 1)
        })
    return jsonify(data)

@app.route('/api/report', methods=['POST'])
def receive_report():
    data = request.get_json()
    if not data or 'host_name' not in data:
        return jsonify({'error': 'invalid data, host_name required'}), 400

    host_name = validate_report_hostname(data['host_name'])
    if not host_name:
        return jsonify({
            'error': (
                'invalid host_name: looks like a Docker container ID. '
                'Run the agent on the host (not inside a container) and set '
                'MONITOR_HOST_NAME to the real hostname, e.g. ubuntu.'
            )
        }), 400

    required_fields = ['cpu_percent', 'mem_percent', 'disk_usage', 'collect_time']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'missing field: {field}'}), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO server_status (host_name, cpu_percent, memory_percent, disk_percent, collect_time)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            host_name,
            float(data['cpu_percent']),
            float(data['mem_percent']),
            float(data['disk_usage']),
            data['collect_time']
        ))
        conn.commit()
        cursor.close()
        conn.close()
        logger.info(f"收到来自 {host_name} 的数据上报")
        return jsonify({'status': 'ok', 'received': True}), 200
    except Exception as e:
        logger.error(f"数据入库失败: {e}")
        return jsonify({'error': 'database error'}), 500

@app.route('/')
def index():
    """首页 - 主机列表"""
    return render_template('hosts.html')

@app.route('/host/<hostname>')
def host_detail_page(hostname):
    return render_template('detail.html', hostname=hostname)

@app.route('/data')
def get_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT collect_time, cpu_percent, memory_percent, disk_percent, host_name
        FROM server_status ORDER BY collect_time DESC LIMIT 50
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    data = []
    for row in rows:
        data.append({
            'time': row['collect_time'].strftime('%Y-%m-%d %H:%M:%S'),
            'cpu': float(row['cpu_percent']),
            'memory': float(row['memory_percent']),
            'disk': float(row['disk_percent']),
            'host': row.get('host_name', 'localhost')
        })
    return jsonify({'status': 'success', 'count': len(data), 'data': data})

@app.route('/health')
def health_check():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        return jsonify({'status': 'healthy', 'database': 'connected'})
    except Exception as e:
        return jsonify({'status': 'unhealthy', 'error': str(e)}), 500

@app.route('/hello')
def hello():
    return '🎉 监控系统已启动！访问 <a href="/">首页</a> 查看主机列表。'

if __name__ == '__main__':
    _debug = os.getenv("FLASK_DEBUG", "false").lower() in ("1", "true", "yes")
    app.run(host="0.0.0.0", port=5000, debug=_debug)

