package com.example.demo.config;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.CacheManager;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * 启动时打印实际使用的 {@link CacheManager}，便于确认是否为 Caffeine（而非默认 ConcurrentMap）。
 */
@Component
public class CacheSetupProbe {

    private final CacheManager cacheManager;

    public CacheSetupProbe(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void logCacheManager() {
        System.out.println("[Cache] CacheManager 实现类: " + cacheManager.getClass().getName());
        System.out.println("[Cache] 已注册缓存名: " + cacheManager.getCacheNames());
    }
}
