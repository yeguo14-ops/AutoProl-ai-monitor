﻿# monitor_project · 服务器资源监控平台（Python 控制端）· 架构与技术点解读

> 自我讲述：理解每个模块做什么、用了什么技术、为什么这么设计。
>
> 说明：本仓库是整套 **AotuPC_ai_monitor 平台**的 **Python 控制端核心**（接收上报、落库、告警、Web 展示）；配套的 `ai_monitor_service`（Java Spring Boot，负责调用大模型）与 MySQL / Redis 是其协作对象。本文聚焦本仓库内部怎么组织。

---

## 一、这个仓库是做什么的

一句话：**它是整个监控平台的"接收中枢 + 决策大脑 + 展示窗口"**，接收各被控主机 Agent 上报的 CPU / 内存 / 磁盘 / 系统日志数据，落库到 MySQL，把日志交给 Java 侧的 DeepSeek 大模型做语义归类与风险判断，达到阈值或检测到高风险时自动发邮件告警，并提供 Web 页面回看历史数据。

它不是单进程脚本，而是按 **三层分层架构** 组织的 Python 项目，最终被打包成 Docker 镜像与整套平台一起编排部署。采集端统一用 `agent.py` 上报，控制端本身不跑采集。

核心依赖（`requirements.txt`）：`psutil`（采集）、`Flask`（Web）、`PyMySQL`（落库）、`redis`（防刷）、`requests`（调 Java AI）、`python-dotenv`（配置）。

## 二、整体架构：三层分层 + Agent 上报

```
┌────────────── 被控主机（Agent 模式，生产推荐）──────────────┐
│  agent.py（psutil 采集 + systemd 守护）                     │
│     └─ POST http://控制端:5000/api/report ──► 上报指标       │
└──────────────────────────────┬─────────────────────────────┘
                               │
┌──────────────────────────────▼─────────────────────────────┐
│  控制端（本仓库，打包进 docker-compose 的 web 容器）          │
│                                                              │
│  入口层（根目录）                                              │
│   app.py     Flask Web：REST 接口 + 页面渲染                   │
│   agent.py   被控端采集上报（独立运行，无需 Flask）             │
│        │                                                      │
│  业务层 monitor/services/（只做判断，不直接碰库/邮件）          │
│   collector  接收上报数据 + AI 指标增强                        │
│   alerter    告警决策 ──► (repo 发邮件)                       │
│   ai_analyzer  本地关键词兜底分析                              │
│        │                                                      │
│  数据层 monitor/repo/（只读写外部资源）                        │
│   storage→MySQL │ redis_client→Redis │ email_sender→SMTP      │
│   ai_java_client→Java │ hostname │ log_tail                    │
│        │                                                      │
└───────────────┬──────────────────────────────┬───────────────┘
                │ HTTP /api/ai/analyze/log       │
                │ HTTP /api/ai/baseline/cpu      │
        ┌───────▼────────┐            ┌─────────▼────────┐
        │ [java-ai]      │            │ [mysql] MySQL 8   │
        │ Spring Boot    │            │ server_status 表  │
        │ → DeepSeek 大模型│            └──────────────────┘
        └────────────────┘
        Redis（告警冷却防刷，独立于三容器外也可）
```

关键设计：**采集统一走 Agent 上报模式**。被控主机跑 `agent.py` 独立采集，POST 到控制端 `/api/report`。控制端容器本身不采集，只做接收、分析、告警和展示。

## 三、各模块与技术点拆解（每个模块做了什么）

### 1. 入口层（根目录）——只负责"启动 + 暴露边界"

| 文件                    | 职责                     | 关键点                                                                                                                                                 |
| --------------------- | ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| `app.py`              | Flask Web，对外 REST + 页面 | 接口：`/api/hosts`（分页主机列表）、`/api/metrics?host=`（时序指标）、`/api/report`（**Agent 上报入口**）、`/data`、`/health`、`/` 与 `/host/<hostname>`（模板渲染）。跑在 `0.0.0.0:5000` |
| `agent.py`            | 被控端采集上报（唯一采集入口）  | psutil 采指标 → POST 到 `CONTROL_SERVER`；失败降级写 `%TEMP%/monitor_backup_*.jsonl`；校验主机名不是 Docker 容器 ID 才允许启动                                               |
| `logger_config.py`    | 共享日志配置（根级工具）           | `RotatingFileHandler` 滚动写 `logs/monitor.log`（10MB×5），`propagate=False` 防重复                                                                          |
| `monitor/__init__.py` | 包门面                    | 集中导出常用函数，`__version__="1.0.0"`                                                                                                                      |

### 2. 业务层 `monitor/services/` ——只做判断，不直接碰数据库/邮件

- **`collector.py`**：接收 Agent 上报的数据，做 AI 指标增强——`_enrich_with_ai()` 就地写三个增强字段：`cpu_dynamic_threshold`（Java 侧动态 CPU 基线）、`ai_log_analysis`（AI 日志结论）、`ai_analysis_source`（来源标记）。AI 增强失败不拖累基础指标接收。
- **`alerter.py`**：告警决策。**融合动态阈值 + AI 风险等级**：若 Java 侧返回了动态 CPU 基线则用它比较，否则用环境变量静态阈值；CPU/内存/磁盘逐项比较；AI 判定 `riskLevel ∈ {HIGH, CRITICAL}` 时追加独立"高风险日志"告警。发送带重试（`send_alert_with_retry`，最多 3 次），成功后回写 Redis 冷却键。
- **`ai_analyzer.py`**：**本地关键词兜底分析**。当 Java 不可用时，用 `fatal/panic/oom/timeout/error/denied` 等关键词做结构化降级，字段对齐 Java 侧 DTO（`errorType/riskLevel/summary`），保证链路不断。

### 3. 数据层 `monitor/repo/` ——只读写外部资源，不做业务判断

- **`storage.py`**：数据落库。**降级兜底**：MySQL 写失败 → `save_to_cache` 写本地 JSON（`data/cache/monitor_cache.json`，最多 100 条）→ 重启时 `retry_cached_data` 补传（每项最多 3 次、间隔 ≥10s）。建表语句里 `CREATE TABLE IF NOT EXISTS server_status`，并幂等补充 AI 相关列。
- **`redis_client.py`**：Redis 连接（单例）+ **告警冷却防刷**。连不上则返回 None，防刷降级为"不防刷"而非崩溃。
- **`email_sender.py`**：**smtplib (SMTP_SSL)** 发告警邮件。`build_ai_alert_subject` 按告警类型生成不同主题前缀（含 AI 高风险日志、多指标等）；`format_ai_enhanced_alert_body` 拼出"指标 + 阈值说明 + AI 结论 + 日志摘要"四段式正文。配置缺省（SMTP/发件人/授权码/收件人）时只记日志不发。
- **`ai_java_client.py`**：用 **requests/HTTP** 调 Java 服务——`POST /api/ai/analyze/log`（日志分析）、`GET /api/ai/baseline/cpu`（动态 CPU 基线，兼容多种阈值字段名）。`JAVA_AI_IGNORE_ENV_PROXY=true` 默认绕开全局代理，避免虚拟机代理误伤本机 8080。启动时打印解析后的 AI 基址，可脱敏。
- **`hostname.py`**：主机名解析，**专门识别 Docker 容器 ID**（12 位小写十六进制），避免容器内 `gethostname()` 把容器 ID 当主机名入库。优先级：`MONITOR_HOST_NAME` 环境变量 > `/etc/monitor_hostname` 文件 > `gethostname()`。
- **`log_tail.py`**：读系统日志尾部（`SYSLOG_TAIL_LINES` 行，限制读字节数防大文件），按路径优先级取第一个可读文件。

## 四、为什么用 Agent 上报模式

1. **控制端容器不该采集**：容器里 `socket.gethostname()` 拿到的是 12 位 Docker 容器 ID，会被 `hostname.py` 判为非法主机名而拒绝入库。
2. **天然横向扩展**：每台被控主机装 `agent.py`，统一上报到同一个控制端，加机器不用改控制端配置。
3. **解耦清晰**：控制端只负责接收、分析、告警、展示；采集端只管采集上报，职责单一。

## 五、告警决策与"智能"部分（alerter 核心逻辑）

```
静态阈值(env: ALERT_THRESHOLD_CPU/MEM/DISK)  ←───────── 动态 CPU 基线(Java /api/ai/baseline/cpu)
        │                                              （取到则优先用动态值）
        ▼
  CPU / 内存 / 磁盘 逐项比较 ──► 命中则加入 alerts
        │
  AI 日志结论 riskLevel ∈ {HIGH, CRITICAL} ──► 追加【高风险日志】告警
        │
        ▼
  Redis 冷却检查（5 分钟内同类告警只发一次，键 last_{type}_alert_time）
        │
        ▼
  拼邮件（AI 增强正文）→ SMTP 发送（失败重试 3 次）→ 成功后回写冷却键
```

整条降级链：**Java AI → 本地关键词兜底（ai_analyzer）**；**MySQL → 本地 JSON 缓存重试（storage）**；**Redis → 不防刷不崩溃**；**SMTP → 重试 + 日志**。每一层挂了都不让整条链路断掉。

## 六、完整数据流转时序

1. **Agent 采集上报**：`agent.py` 每 60s 用 psutil 采集 CPU/内存/磁盘 + 日志尾部 → POST `/api/report`。
2. **控制端接收**：`app.py.receive_report` 校验主机名与必填字段 → 业务层处理。
3. **AI 增强**：`collector._enrich_with_ai` → `ai_java_client` 调 Java `/api/ai/baseline/cpu` 拿动态阈值、`/api/ai/analyze/log` 拿日志结论；Java 不可用则 `ai_analyzer` 关键词兜底。
4. **落库**：`storage.save_to_mysql_with_fallback` 写 MySQL `server_status`；失败降级本地 JSON + 重试。
5. **告警**：`alerter.check_and_alert` 比较阈值 + AI 风险 → Redis 冷却 → `email_sender` 发邮件（重试）。
6. **展示**：`app.py` 从 MySQL 读历史，`/api/hosts`、`/api/metrics` 供前端/模板渲染回看。

## 七、部署与一键启动

**Docker 编排**（compose v3.3，兼容旧版 docker-compose，`depends_on` 用列表顺序保证 `mysql → java-ai → web` 启动顺序）：

```bash
cp docker/defaults.compose.env .env    # 首次：生成端口/密码/镜像名配置
docker compose build web && docker compose up -d
```

- `web` 容器：`Dockerfile`（python:3.11-slim）安装依赖，入口 `docker/entrypoint.sh`——`exec python app.py` 前台跑 Flask。
- `web` 的 `AI_SERVICE_BASE_URL=http://java-ai:8080`，容器内走服务名互通。
- 端口映射：MySQL **3307**（避免本机 3306 冲突）/ Flask **5000** / Java **8080**。

**被控主机装 Agent**：在每台被监控机器上跑 `agent.py`，设置 `CONTROL_SERVER=http://控制端IP:5000/api/report`，建议用 systemd 守护开机自启。

**Ansible 批量部署**（`ansible/deploy.yml`）：在被控主机装 python3+psutil+requests、下发 `agent.py` 与 `hostname.py`、写 **systemd 服务 `monitor-agent`**（`Restart=always`、`CONTROL_SERVER` 自动取自 inventory 里 control_server 组第一台）、`daemon-reload` 后启动。

## 八、技术点速查表

| 技术点               | 用在哪里                          | 解决什么问题                  |
| ----------------- | ----------------------------- | ----------------------- |
| Python psutil     | agent 采集                    | 跨平台取 CPU/内存/磁盘          |
| Flask + 模板        | app.py Web 展示                 | REST 接口 + 页面渲染          |
| PyMySQL + 建表/加列   | storage 落库                    | 写 MySQL，失败降级文件缓存        |
| Redis + 冷却键       | redis_client                  | 告警防刷，5 分钟内不重复轰炸         |
| smtplib + 重试      | email_sender                  | 发告警邮件，失败自动重试            |
| 动态阈值 vs 静态阈值      | alerter                       | 用 AI 基线自适应，否则配置兜底       |
| requests 调 Java   | ai_java_client                | HTTP 调大模型分析与动态基线，绕代理    |
| 降级兜底链             | ai_analyzer / storage / redis | 各层挂掉链路仍可用               |
| 主机名解析             | hostname                      | 识别 Docker 容器 ID，避免误当主机名 |
| systemd 守护        | Ansible deploy / agent 部署     | Agent 开机自启、崩溃自愈         |
| docker-compose 编排 | 部署                            | 与 Java/MySQL 有序协作       |

## 九、一句话总结

> 这个仓库是监控平台的 **Python 控制端**：入口层（`app.py` Flask / `agent.py` 上报）→ 业务层（`collector` 接收增强、`alerter` 融合动态阈值 + AI 风险告警、`ai_analyzer` 关键词兜底）→ 数据层（`storage` 落 MySQL、`redis_client` 防刷、`email_sender` 发邮件、`ai_java_client` 调 Java 大模型）。采集统一走被控主机 **Agent 上报** 模式，整套可打包成 Docker 三容器并用 **Ansible** 批量部署。技术点覆盖 psutil 采集、动态阈值告警、Redis 防刷、SMTP 重试与层层降级兜底。
