package com.example.demo.model.dto;

public class AiLogAnalysisRequest {
    private String logText;

    // 快速生成Getter和Setter: 在VS Code中，右键 -> Source Action -> Generate Getters and
    // Setters
    public String getLogText() {
        return logText;
    }

    public void setLogText(String logText) {
        this.logText = logText;
    }

}
