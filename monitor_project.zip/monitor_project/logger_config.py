import sys
import logging
import os
from logging.handlers import RotatingFileHandler

# 临时文件管理配置
sys.dont_write_bytecode = False
sys.pycache_prefix = "./cache/"

def setup_logger(name, log_file=None):
    """
    配置并返回一个logger实例
    :param name: logger的名称，通常使用__name__
    :param log_file: 日志文件路径，如果为None则使用默认路径
    :return: 配置好的logger对象
    """
    # 如果没有提供log_file参数，使用基于当前模块目录的默认路径
    if not log_file:
        # 获取当前模块所在的目录，然后构建 logs/monitor.log 路径
        log_file = os.path.join(os.path.dirname(__file__), 'logs', 'monitor.log')
    
    # 1. 创建logger
    logger = logging.getLogger(name)
    
    # ★★★ 关键修复：在创建处理器之前检查是否已有处理器 ★★★
    # 如果这个logger已经有处理器了，直接返回，避免重复添加
    if logger.handlers:
        return logger
    
    # 设置默认级别，可以被handler覆盖
    logger.setLevel(logging.DEBUG)
    
    # 2. 创建日志格式
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 3. 创建控制台处理器 (Console Handler)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)  # 控制台只显示INFO及以上级别
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 4. 创建文件处理器 (File Handler)，支持轮转防止文件过大
    # 确保日志目录存在
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    # 每个日志文件最大10MB，最多保留5个备份
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)  # 文件记录更详细的DEBUG级别信息
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # 不向父 logger（如 'monitor'）传播，避免与 default_logger 重复写同一文件/控制台
    logger.propagate = False

    return logger

# 提供一个可以直接导入的默认logger（用于快速测试或简单脚本）
default_logger = setup_logger('monitor')
