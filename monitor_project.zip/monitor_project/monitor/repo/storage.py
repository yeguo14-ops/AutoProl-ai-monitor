# monitor/storage.py
"""
数据存储模块
功能：数据库操作、本地文件存储
"""
import json
import pymysql
import os
import datetime
from dotenv import load_dotenv
from logger_config import setup_logger
from .hostname import is_docker_container_id, resolve_monitor_hostname

load_dotenv()
logger = setup_logger(__name__)


def _column_exists(cursor, table_name: str, column_name: str) -> bool:
    cursor.execute(
        """
        SELECT COUNT(*) AS c FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s
        """,
        (table_name, column_name),
    )
    row = cursor.fetchone()
    if not row:
        return False
    # DictCursor 返回 dict，不能用 row[0]（会触发 KeyError: 0）
    if isinstance(row, dict):
        if "c" in row:
            return bool(row["c"])
        if "C" in row:
            return bool(row["C"])
        for val in row.values():
            return bool(val)
        return False
    return bool(row[0])


def ensure_server_status_extra_columns(cursor):
    """为已存在的表补充 AI / 日志相关列（幂等）。"""
    alters = [
        ("syslog_tail_preview", "TEXT NULL"),
        ("ai_log_analysis_json", "LONGTEXT NULL"),
        ("cpu_dynamic_threshold", "FLOAT NULL"),
        ("ai_analysis_source", "VARCHAR(32) NULL"),
    ]
    for col, ddl in alters:
        if not _column_exists(cursor, "server_status", col):
            try:
                cursor.execute(f"ALTER TABLE server_status ADD COLUMN {col} {ddl}")
                logger.info("已扩展表 server_status，新增列: %s", col)
            except pymysql.Error as e:
                logger.warning("添加列 %s 时出现异常（可忽略若已存在）: %s", col, e)


def _serialize_ai_payload(data) -> tuple:
    preview = (data.get("raw_syslog_tail") or "")[:16000]
    ai = data.get("ai_log_analysis")
    if ai is None:
        ai_json = None
    elif isinstance(ai, (dict, list)):
        try:
            ai_json = json.dumps(ai, ensure_ascii=False, default=str)
        except (TypeError, ValueError) as e:
            logger.warning("ai_log_analysis 无法 JSON 序列化，改为 str: %s", e)
            ai_json = str(ai)
    else:
        ai_json = str(ai)
    dyn = data.get("cpu_dynamic_threshold")
    src = data.get("ai_analysis_source")
    return preview, ai_json, dyn, src


def get_db_config():
    """获取数据库配置"""
    return {
        'host': os.getenv('DB_HOST', 'localhost'),
        'user': os.getenv('DB_USER', 'root'),
        'password': os.getenv('DB_PASSWORD', ''),
        'database': os.getenv('DB_NAME', 'monitor'),
        'port': int(os.getenv('DB_PORT', 3306)),
        'charset': 'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor
    }

def save_to_mysql(data):
    """把数据写入 MySQL 数据库"""
    if data is None:
        return False
    
    db_config = get_db_config()
    connection = None
    cursor = None
    
    try:
        connection = pymysql.connect(**db_config)
        cursor = connection.cursor()
        
        # 建表语句
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS server_status (
            id INT AUTO_INCREMENT PRIMARY KEY,
            collect_time DATETIME NOT NULL,
            cpu_percent FLOAT NOT NULL,
            memory_percent FLOAT NOT NULL,
            disk_percent FLOAT NOT NULL,
            host_name VARCHAR(50) DEFAULT 'localhost',
            syslog_tail_preview TEXT NULL,
            ai_log_analysis_json LONGTEXT NULL,
            cpu_dynamic_threshold FLOAT NULL,
            ai_analysis_source VARCHAR(32) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
        cursor.execute(create_table_sql)
        ensure_server_status_extra_columns(cursor)

        insert_sql = """
        INSERT INTO server_status (
            collect_time, cpu_percent, memory_percent, disk_percent, host_name,
            syslog_tail_preview, ai_log_analysis_json, cpu_dynamic_threshold, ai_analysis_source
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        host_name = resolve_monitor_hostname()
        if is_docker_container_id(host_name) and os.getenv(
            "MONITOR_ALLOW_CONTAINER_HOSTNAME", ""
        ).lower() not in ("1", "true", "yes"):
            logger.error(
                "跳过入库：hostname=%s 为 Docker 容器 ID；请设 MONITOR_HOST_NAME 或 "
                "RUN_MONITOR_SCHEDULER=false（由宿主机 agent 采集）",
                host_name,
            )
            return False

        preview, ai_json, dyn_thr, ai_src = _serialize_ai_payload(data)

        cursor.execute(
            insert_sql,
            (
                data["time"],
                data["cpu"],
                data["mem"],
                data["disk"],
                host_name,
                preview or None,
                ai_json,
                dyn_thr,
                ai_src,
            ),
        )
        
        connection.commit()
        logger.info(f"✅ 数据已写入MySQL: {data['time']} | CPU:{data['cpu']}%")
        return True
        
    except pymysql.Error as e:
        logger.error("❌ 数据库操作失败: %s", e, exc_info=True)
        if connection:
            connection.rollback()
        return False

    except Exception as e:
        logger.exception(
            "❌ 保存 MySQL 时发生非预期异常: type=%s repr=%s",
            type(e).__name__,
            repr(e),
        )
        return False
        
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def save_to_mysql_with_fallback(data):
    """
    保存数据到MySQL，失败时自动降级到本地缓存
    :return: 是否成功（包括降级成功）
    """
    if data is None:
        return False
    
    mysql_success = save_to_mysql(data)  # 调用 save_to_mysql 函数
    
    if mysql_success:
        return True
    else:
        # MySQL失败，启动降级方案：本地缓存
        logger.warning("数据库保存失败，启用降级方案：保存到本地缓存")
        cache_success = save_to_cache(data)
        return cache_success  # 返回降级方案是否成功

def save_to_file(data, filename="data/monitor.log"):
    """写入本地日志文件"""
    if data is None:
        return
    
    try:
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        extra = {
            "cpu_dynamic_threshold": data.get("cpu_dynamic_threshold"),
            "ai_analysis_source": data.get("ai_analysis_source"),
            "ai_log_analysis": data.get("ai_log_analysis"),
        }
        extra_s = json.dumps(extra, ensure_ascii=False, default=str)
        if len(extra_s) > 4000:
            extra_s = extra_s[:4000] + "…"
        with open(filename, "a", encoding="utf-8") as f:
            line = (
                f"{data['time']}, CPU:{data['cpu']}%, MEM:{data['mem']}%, "
                f"DISK:{data['disk']}% | extra={extra_s}\n"
            )
            f.write(line)
            
    except Exception as e:
        logger.error(f"❌ 写入日志文件失败: {e}")
def save_to_cache(data, cache_file="data/cache/monitor_cache.json"):
    """
    降级方案：将数据保存到本地JSON缓存文件
    :return: 是否成功
    """
    if data is None:
        return False
    
    try:
        cache_dir = os.path.dirname(cache_file)
        if cache_dir and not os.path.exists(cache_dir):
            os.makedirs(cache_dir, exist_ok=True)
        
        # 准备缓存条目
        cache_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "data": {
                "time": data["time"].isoformat() if hasattr(data["time"], 'isoformat') else str(data["time"]),
                "cpu": data["cpu"],
                "mem": data["mem"],
                "disk": data["disk"],
                "raw_syslog_tail": data.get("raw_syslog_tail"),
                "ai_log_analysis": data.get("ai_log_analysis"),
                "cpu_dynamic_threshold": data.get("cpu_dynamic_threshold"),
                "ai_analysis_source": data.get("ai_analysis_source"),
            },
            "retry_count": 0,
            "last_retry": None
        }
        
        # 读取现有缓存
        cache_list = []
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_list = json.load(f)
                    if not isinstance(cache_list, list):
                        cache_list = []  # 如果文件损坏，重置
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"缓存文件损坏或读取失败，将创建新的: {e}")
                cache_list = []
        
        # 添加新条目
        cache_list.append(cache_entry)
        
        # 限制缓存大小（例如最多100条）
        MAX_CACHE_SIZE = 100
        if len(cache_list) > MAX_CACHE_SIZE:
            cache_list = cache_list[-MAX_CACHE_SIZE:]
            logger.info(f"缓存已超过{MAX_CACHE_SIZE}条，保留最新记录")
        
        # 写回文件
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_list, f, ensure_ascii=False, indent=2)
        
        logger.info(f"数据已降级保存到本地缓存: {cache_file} (当前{len(cache_list)}条)")
        return True
        
    except Exception as e:
        logger.error(f"保存到本地缓存失败: {e}", exc_info=True)
        return False

def retry_cached_data(cache_file="data/cache/monitor_cache.json", max_retries_per_item=3):
    """
    尝试将缓存中的数据重新存入数据库
    :return: (成功数, 失败数)
    """
    if not os.path.exists(cache_file):
        return 0, 0
    
    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            cache_list = json.load(f)
    except Exception as e:
        logger.error(f"读取缓存文件失败: {e}")
        return 0, 0
    
    if not cache_list:
        return 0, 0
    
    success_count = 0
    failed_count = 0
    remaining_cache = []
    current_time = datetime.datetime.now()
    
    for item in cache_list:
        # 检查是否超过重试次数
        if item.get('retry_count', 0) >= max_retries_per_item:
            logger.warning(f"缓存数据已达到最大重试次数，丢弃: {item.get('timestamp')}")
            failed_count += 1
            continue
        
        # 检查重试间隔（至少等待10秒）
        last_retry = item.get('last_retry')
        if last_retry:
            try:
                last_retry_time = datetime.datetime.fromisoformat(last_retry)
                if (current_time - last_retry_time).total_seconds() < 10:
                    remaining_cache.append(item)  # 未到重试时间，保留
                    continue
            except (ValueError, TypeError):
                pass
        
        # 尝试重试：将缓存数据写入数据库
        try:
            data = item['data']
            # 将字符串时间转换回datetime对象（save_to_mysql需要的格式）
            data['time'] = datetime.datetime.fromisoformat(data['time'])
            
            if save_to_mysql(data):  # 调用原有的数据库保存函数
                success_count += 1
                logger.info(f"成功重试缓存数据: {item.get('timestamp')}")
            else:
                # 重试失败，更新重试信息
                item['retry_count'] = item.get('retry_count', 0) + 1
                item['last_retry'] = current_time.isoformat()
                remaining_cache.append(item)
                failed_count += 1
                
        except Exception as e:
            logger.error(f"重试缓存数据时出错: {e}")
            item['retry_count'] = item.get('retry_count', 0) + 1
            item['last_retry'] = current_time.isoformat()
            remaining_cache.append(item)
            failed_count += 1
    
    # 保存剩余的缓存
    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(remaining_cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"保存剩余缓存失败: {e}")
    
    if success_count > 0:
        logger.info(f"缓存重试完成: 成功 {success_count} 条，失败 {failed_count} 条，剩余 {len(remaining_cache)} 条待重试")
    
    return success_count, failed_count
