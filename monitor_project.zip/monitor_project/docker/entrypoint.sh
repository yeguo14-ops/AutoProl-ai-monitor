#!/bin/sh
set -e
cd /app

# 后台运行采集调度（与 Flask 同镜像，一键启动完整能力）
if [ "${RUN_MONITOR_SCHEDULER:-false}" = "true" ]; then
  echo "[entrypoint] starting monitor scheduler (main.py) in background..."
  python main.py &
fi

echo "[entrypoint] starting Flask (app.py) on 0.0.0.0:5000 ..."
exec python app.py
