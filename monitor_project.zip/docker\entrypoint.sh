﻿#!/bin/sh
set -e
cd /app

echo "[entrypoint] starting Flask (app.py) on 0.0.0.0:5000 ..."
exec python app.py