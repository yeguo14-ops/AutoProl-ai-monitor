Day 13-16 容器化与一键启动（monitor_project）

一、前置条件
1. Docker Engine + docker-compose（V1）或 docker compose（V2）均可。
   compose 文件使用 version 3.3，兼容 Ubuntu 常见旧版 docker-compose；首次启动若 Java/Web 连库失败，等 MySQL 就绪后再执行一次 docker-compose up -d（容器多为 restart: unless-stopped 会自动重试）。
2. Java AI 镜像默认名：ai-monitor-service:latest（可在 .env 里改 JAVA_AI_IMAGE）。

二、必须先有「项目根目录 .env」（否则 ${MYSQL_ROOT_PASSWORD} 为空会启动失败）
  cd monitor_project
  cp docker/defaults.compose.env .env
  # 按需编辑 .env：密码、端口、镜像名

说明：旧版 docker-compose 不支持 YAML 里的 ${VAR:-default}，默认值已全部写在 docker/defaults.compose.env，
      复制为 .env 后由 Compose 做变量替换。

三、MySQL 8 与 PyMySQL
  必须安装 cryptography（已在 requirements.txt），否则报错：
  RuntimeError: 'cryptography' package is required for sha256_password or caching_sha2_password
  修改依赖后请重新构建：docker-compose build web && docker-compose up -d

四、首次启动
  docker compose build web    # 或 docker-compose build web
  docker compose up -d

五、端口冲突（常见）
  若报错 bind 0.0.0.0:3306 address already in use：宿主已在跑 MySQL。
  在 .env 里改 MYSQL_PUBLISH_PORT=3307（或别的空闲端口），再 docker-compose up -d。
  用工具连「Docker 里的库」时用 127.0.0.1:3307，容器之间仍用主机名 mysql、端口 3306。

六、验证（Day 15-16）
  浏览器 http://localhost:5000 ；健康检查 http://localhost:5000/health

七、Spring Boot 环境变量
若键名与 compose 中 java-ai.environment 不一致，请直接改 docker-compose.yml。

八、主机名与 Agent（重要）
  · 控制端 compose 默认 RUN_MONITOR_SCHEDULER=false，避免 web 容器用容器 ID 当主机名。
  · Agent 必须装在「被监控的宿主机」上，不要 docker run agent；部署见 ansible/deploy.yml。
  · 每台 agent 设置 MONITOR_HOST_NAME=真实主机名（Ansible 已自动用 ansible_hostname）。
  · 若列表里已有 91cd0bd8b1f3 等乱码，先停掉容器里的 agent，再执行：
      docker compose exec mysql mysql -umonitor -p你的密码 monitor < docker/cleanup-docker-hostnames.sql
    然后重建 web：docker compose build web && docker compose up -d

九、仅 Web、不要后台采集
在 .env 中设置：RUN_MONITOR_SCHEDULER=false（defaults.compose.env 已是 false）

十、数据卷
  docker compose down -v 会删除 mysql_data（慎用）。
