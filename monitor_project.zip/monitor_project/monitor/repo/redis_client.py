# monitor/redis_client.py
"""
Redis连接模块
功能：管理Redis连接，提供防刷功能支持
"""

import redis
import os
from logger_config import setup_logger
from dotenv import load_dotenv

load_dotenv()
logger = setup_logger(__name__)

_redis_client = None

def get_redis_client():
    """获取Redis客户端连接（单例模式）"""
    global _redis_client
    
    if _redis_client is None:
        try:
            _redis_client = redis.Redis(
                host=os.getenv('REDIS_HOST', 'localhost'),
                port=int(os.getenv('REDIS_PORT', 6379)),
                db=int(os.getenv('REDIS_DB', 0)),
                decode_responses=True
            )
            # 测试连接
            _redis_client.ping()
            logger.info("✅ Redis连接成功")
        except redis.ConnectionError as e:
            logger.warning(f"⚠️ Redis连接失败，防刷功能将不可用: {e}")
            _redis_client = None
        except Exception as e:
            logger.warning(f"⚠️ Redis初始化异常: {e}")
            _redis_client = None
    
    return _redis_client
