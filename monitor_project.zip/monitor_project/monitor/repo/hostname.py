"""
监控主机名解析：避免 Docker 容器内 socket.gethostname() 返回 12 位容器 ID。
优先级：MONITOR_HOST_NAME / MONITOR_HOSTNAME 环境变量 > /etc/monitor_hostname > gethostname()
"""
import logging
import os
import re
import socket

logger = logging.getLogger(__name__)

# Docker 默认 hostname = 容器 ID 前 12 位（小写十六进制）
_DOCKER_SHORT_ID = re.compile(r"^[a-f0-9]{12}$", re.IGNORECASE)

_HOSTNAME_FILE_CANDIDATES = (
    "/etc/monitor_hostname",
    "/data/monitor_hostname",
)


def is_docker_container_id(name: str) -> bool:
    """判断是否为 Docker 自动分配的 12 位容器短 ID。"""
    return bool(name and _DOCKER_SHORT_ID.match(name.strip()))


def resolve_monitor_hostname() -> str:
    """返回用于入库、告警、AI 基线的逻辑主机名。"""
    for env_key in ("MONITOR_HOST_NAME", "MONITOR_HOSTNAME"):
        explicit = (os.getenv(env_key) or "").strip()
        if explicit:
            return explicit[:255]

    for path in _HOSTNAME_FILE_CANDIDATES:
        try:
            with open(path, encoding="utf-8") as f:
                from_file = f.read().strip()
            if from_file and not is_docker_container_id(from_file):
                return from_file[:255]
        except OSError:
            continue

    name = (socket.gethostname() or "").strip() or "localhost"
    if is_docker_container_id(name):
        logger.warning(
            "当前 hostname=%s 疑似 Docker 容器 ID；请设置 MONITOR_HOST_NAME（宿主机 agent）"
            "或将 web 容器 RUN_MONITOR_SCHEDULER=false，勿在容器内跑 agent。",
            name,
        )
    return name[:255]


def validate_report_hostname(host_name: str) -> str | None:
    """
    校验 agent 上报的 host_name。若为容器 ID 返回 None（应拒绝入库）。
    """
    hn = (host_name or "").strip()
    if not hn:
        return None
    if is_docker_container_id(hn):
        return None
    return hn[:255]
