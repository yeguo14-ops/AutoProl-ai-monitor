# monitor/alerter.py
"""
告警检查模块
功能：融合动态阈值与 Java AI 日志结论，触发智能告警并发送邮件
"""

import os
import time
import datetime
from logger_config import setup_logger
from ..repo.email_sender import send_alert, format_ai_enhanced_alert_body, build_ai_alert_subject
from ..repo.hostname import resolve_monitor_hostname
from ..repo.redis_client import get_redis_client
from dotenv import load_dotenv

load_dotenv()
logger = setup_logger(__name__)


def send_alert_with_retry(subject, content, max_retries=2, retry_delay=5):
    """发送告警邮件，支持失败重试"""
    for attempt in range(max_retries + 1):
        try:
            logger.info("尝试发送告警邮件 (第 %s/%s 次)...", attempt + 1, max_retries + 1)
            success = send_alert(subject, content)

            if success:
                logger.info("告警邮件发送成功 (第 %s 次尝试)", attempt + 1)
                return True
            if attempt < max_retries:
                logger.warning("邮件发送返回失败，%s秒后重试...", retry_delay)
                time.sleep(retry_delay)
            else:
                logger.error("邮件发送失败，已达最大重试次数")
                return False

        except Exception as e:
            if attempt < max_retries:
                logger.warning("发送邮件时异常: %s，%s秒后重试...", e, retry_delay)
                time.sleep(retry_delay)
            else:
                logger.error("发送邮件异常，已达最大重试次数: %s", e, exc_info=True)
                return False
    return False


def check_and_alert(data):
    """
    告警决策（融合动态阈值 + AI 风险等级），并发送 AI 增强型邮件正文。
    决策流：动态阈值可用则用于 CPU，否则静态；CPU/内存/磁盘逐项比较；
    再检查 AI riskLevel 为 HIGH/CRITICAL 时追加独立「高风险日志」告警。
    """
    if data is None:
        logger.warning("告警检查：传入数据为空，跳过")
        return False

    try:
        static_cpu_threshold = float(os.getenv("ALERT_THRESHOLD_CPU", 80.0))
        cpu_threshold = static_cpu_threshold
        cpu_used_dynamic = False

        dyn = data.get("cpu_dynamic_threshold")
        if dyn is not None:
            try:
                dv = float(dyn)
                if dv > 0:
                    cpu_threshold = dv
                    cpu_used_dynamic = True
                    logger.debug("CPU 告警阈值使用动态基线: %s%%", cpu_threshold)
            except (TypeError, ValueError):
                pass

        mem_threshold = float(os.getenv("ALERT_THRESHOLD_MEM", 85.0))
        disk_threshold = float(os.getenv("ALERT_THRESHOLD_DISK", 90.0))

        alerts = []
        alert_types = []

        # CPU
        if data["cpu"] > cpu_threshold:
            if cpu_used_dynamic:
                alert_msg = (
                    f"警告：CPU 使用率 {data['cpu']}%，已超过动态计算阈值 {cpu_threshold}% "
                    f"（静态兜底阈值 {static_cpu_threshold}%）。"
                )
            else:
                alert_msg = (
                    f"警告：CPU 使用率 {data['cpu']}%，已超过静态阈值 {cpu_threshold}% "
                    f"（环境变量 ALERT_THRESHOLD_CPU）。"
                )
            alerts.append(alert_msg)
            alert_types.append("cpu")
            logger.warning(alert_msg)

        # 内存
        if data["mem"] > mem_threshold:
            alert_msg = f"警告：内存使用率 {data['mem']}%，已超过静态阈值 {mem_threshold}%。"
            alerts.append(alert_msg)
            alert_types.append("mem")
            logger.warning(alert_msg)

        # 磁盘
        if data["disk"] > disk_threshold:
            alert_msg = f"警告：磁盘使用率 {data['disk']}%，已超过静态阈值 {disk_threshold}%。"
            alerts.append(alert_msg)
            alert_types.append("disk")
            logger.warning(alert_msg)

        # AI 高风险日志（独立于传统指标，可与 CPU 等同时存在）
        ai_block = data.get("ai_log_analysis")
        if isinstance(ai_block, dict):
            risk = str(ai_block.get("riskLevel") or ai_block.get("risk_level") or "").upper()
            if risk in ("HIGH", "CRITICAL"):
                et = ai_block.get("errorType") or ai_block.get("error_type") or "Unknown"
                sm = (
                    ai_block.get("summary")
                    or ai_block.get("message")
                    or ai_block.get("analysis")
                    or ""
                )
                sm_short = (str(sm)[:400] + "…") if len(str(sm)) > 400 else str(sm)
                ai_msg = (
                    f"【高风险日志】AI 判定 riskLevel={risk}，错误类型：{et}。"
                    f"分析提示：{sm_short or '（无摘要字段）'}"
                )
                alerts.append(ai_msg)
                alert_types.append("ai_log")
                logger.warning(ai_msg)

        if not alerts:
            logger.debug("告警检查：所有指标正常，且 AI 风险未达 HIGH/CRITICAL，未触发告警")
            return False

        r = get_redis_client()
        should_send = True

        for alert_type in alert_types:
            if r:
                last_alert_key = f"last_{alert_type}_alert_time"
                last_time = r.get(last_alert_key)

                if last_time is not None:
                    time_diff = time.time() - float(last_time)
                    if time_diff < 300:
                        logger.info("5分钟内已发送过%s告警，本次跳过", alert_type.upper())
                        should_send = False
                        break

        if not should_send:
            return False

        alert_message = "\n".join(alerts)
        logger.info("触发告警条件: %s", alert_message)

        host_name = resolve_monitor_hostname()
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        subject = build_ai_alert_subject(host_name, current_time, alert_types)

        content = format_ai_enhanced_alert_body(
            hostname=host_name,
            occurred_at=current_time,
            metrics={"cpu": data["cpu"], "mem": data["mem"], "disk": data["disk"]},
            alert_bullets=alerts,
            alert_codes=alert_types,
            cpu_threshold_effective=cpu_threshold,
            cpu_used_dynamic=cpu_used_dynamic,
            static_cpu_threshold=static_cpu_threshold,
            mem_threshold=mem_threshold,
            disk_threshold=disk_threshold,
            ai_analysis=ai_block if isinstance(ai_block, dict) else None,
            ai_source=str(data.get("ai_analysis_source") or ""),
            log_preview=data.get("raw_syslog_tail"),
        )

        logger.info("正在尝试发送告警邮件...")
        send_success = send_alert_with_retry(subject, content, max_retries=2)

        if send_success:
            logger.info("告警邮件发送成功")
            if r:
                for alert_type in alert_types:
                    r.set(f"last_{alert_type}_alert_time", time.time())
        else:
            logger.error("告警邮件发送失败")

        return send_success

    except Exception as e:
        logger.exception("告警检查或发送过程内部出错: %s", e)
        return False
