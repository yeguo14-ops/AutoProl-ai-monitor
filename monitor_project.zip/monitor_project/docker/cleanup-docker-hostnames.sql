-- 删除误用 Docker 容器短 ID 作为 host_name 的历史数据（12 位小写十六进制）
-- 在控制端执行，例如：
--   docker compose exec mysql mysql -umonitor -pmonitor_pass monitor < docker/cleanup-docker-hostnames.sql

DELETE FROM server_status
WHERE host_name REGEXP '^[a-f0-9]{12}$';
