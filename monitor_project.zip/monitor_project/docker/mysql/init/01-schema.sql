-- 首次初始化数据卷时执行；与 monitor/storage.py 中表结构一致
USE monitor;

CREATE TABLE IF NOT EXISTS server_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    collect_time DATETIME NOT NULL,
    cpu_percent FLOAT NOT NULL,
    memory_percent FLOAT NOT NULL,
    disk_percent FLOAT NOT NULL,
    host_name VARCHAR(50) DEFAULT 'localhost',
    syslog_tail_preview TEXT NULL,
    ai_log_analysis_json LONGTEXT NULL,
    cpu_dynamic_threshold FLOAT NULL,
    ai_analysis_source VARCHAR(32) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
