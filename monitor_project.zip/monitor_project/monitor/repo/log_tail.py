# monitor/log_tail.py
"""
读取系统日志尾部若干行（Linux syslog/messages 等；Windows 尝试常见路径）。
"""

import os
from typing import List

from logger_config import setup_logger

logger = setup_logger(__name__)


def _default_log_paths() -> List[str]:
    paths = [
        "/var/log/syslog",
        "/var/log/messages",
        "/var/log/system.log",
    ]
    extra = os.getenv("SYSTEM_LOG_PATHS", "").strip()
    if extra:
        for p in extra.split(","):
            p = p.strip()
            if p and p not in paths:
                paths.insert(0, p)
    return paths


def tail_file_lines(path: str, max_lines: int, max_read_bytes: int = 512 * 1024) -> str:
    """读取文本文件末尾约 max_lines 行（通过限制读取字节数控制大文件）。"""
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            read_size = min(size, max_read_bytes)
            f.seek(size - read_size)
            chunk = f.read().decode("utf-8", errors="replace")
    except OSError as e:
        logger.debug("无法读取日志文件 %s: %s", path, e)
        return ""
    lines = chunk.splitlines()
    if len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "\n".join(lines)


def collect_system_log_tail(max_lines: int = 80) -> str:
    """
    依次尝试配置的日志路径，返回第一个成功读取的非空尾部文本。
    """
    for path in _default_log_paths():
        if not path or not os.path.isfile(path):
            continue
        text = tail_file_lines(path, max_lines=max_lines)
        if text.strip():
            logger.debug("已采集系统日志尾部: path=%s lines≈%s", path, max_lines)
            return text
    logger.debug("未找到可读的系统日志文件（可设置 SYSTEM_LOG_PATHS）")
    return ""
