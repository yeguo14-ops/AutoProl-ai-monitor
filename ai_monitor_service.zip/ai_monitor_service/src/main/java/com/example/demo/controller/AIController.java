package com.example.demo.controller;

import com.example.demo.model.dto.AiLogAnalysisRequest;
import com.example.demo.model.dto.AiLogAnalysisResponse;
import com.example.demo.model.dto.CpuBaselineResponse;
import com.example.demo.service.DeepSeekService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/api/ai")
public class AIController {

    @Autowired
    private DeepSeekService deepSeekService;

    // 接口1: AI日志分析 (使用真实 DeepSeek API)
    @PostMapping("/analyze/log")
    public Mono<AiLogAnalysisResponse> analyzeLog(@RequestBody AiLogAnalysisRequest request) {
        System.out.println("接收到日志分析请求: " + request.getLogText());

        return Mono.fromCallable(() -> deepSeekService.analyzeLogWithDeepSeek(request.getLogText()))
                .subscribeOn(Schedulers.boundedElastic())
                .doOnSuccess(response -> System.out.println(
                        "AI 分析成功 | 日志语义类型=" + response.getErrorType() + " | 风险=" + response.getRiskLevel()))
                .doOnError(error -> System.err.println("AI 分析失败: " + error.getMessage()));
    }

    // 接口2: CPU动态基线 (保持模拟数据)
    @GetMapping("/baseline/cpu")
    public CpuBaselineResponse getCpuBaseline(
            @RequestParam(value = "hostname") String hostname) {
        System.out.println("请求主机基线: " + hostname);

        // 模拟计算逻辑
        double mean = 65.5;
        double std = 12.3;
        double threshold = mean + 2 * std;

        CpuBaselineResponse response = new CpuBaselineResponse();
        response.setHostname(hostname);
        response.setMean(mean);
        response.setStd(std);
        response.setDynamicThreshold(threshold);
        return response;
    }
}