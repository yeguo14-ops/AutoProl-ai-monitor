# monitor/ai_analyzer.py
"""
AI 分析服务模块 
功能：提供智能日志分析，失败时降级到规则分析
"""

import os
from logger_config import setup_logger
from dotenv import load_dotenv

load_dotenv()
logger = setup_logger(__name__)

def analyze_with_ai(log_data, system_prompt=None):
    """
    使用AI服务分析数据 (预留接口)
    实际调用需要接入DeepSeek等API
    """
    # 检查是否启用AI服务
    if os.getenv('AI_SERVICE_ENABLED', 'false').lower() != 'true':
        logger.debug("AI服务未启用")
        return None
    
    # 这里放置实际的AI API调用代码
    # 例如：requests.post(API_URL, json={...})
    
    logger.warning("AI服务接口已预留，但具体实现需接入API")
    return None

def fallback_keyword_analysis(log_data):
    """
    降级方案：基于关键词的简单规则分析
    """
    alerts = []
    # 简单规则示例
    if isinstance(log_data, str):
        lower = log_data.lower()
        if "error" in lower or "fatal" in lower:
            alerts.append('日志中包含 "error" / "fatal" 类关键词')
        if "timeout" in lower:
            alerts.append('日志中包含 "timeout" 关键词')
        if "oom" in lower or "out of memory" in lower:
            alerts.append("日志中出现内存相关异常提示")
        if "denied" in lower or "permission" in lower:
            alerts.append("日志中出现权限/拒绝类提示")

    if alerts:
        return "规则分析发现: " + "; ".join(alerts)
    return "规则分析未发现明显问题"


def structured_fallback_from_log_text(log_text: str) -> dict:
    """
    与 Java 侧结构对齐的本地兜底结果（字段尽量通用）。
    """
    summary = fallback_keyword_analysis(log_text or "")
    lower = (log_text or "").lower()
    risk = "LOW"
    err_type = "NONE"
    if any(k in lower for k in ("fatal", "panic", "segfault", "kernel oops")):
        risk, err_type = "HIGH", "KERNEL_OR_CRITICAL"
    elif "oom" in lower or "out of memory" in lower:
        risk, err_type = "HIGH", "MEMORY"
    elif "error" in lower or "failed" in lower:
        risk, err_type = "MEDIUM", "APPLICATION_ERROR"
    elif "timeout" in lower:
        risk, err_type = "MEDIUM", "TIMEOUT"
    return {
        "errorType": err_type,
        "riskLevel": risk,
        "summary": summary,
        "source": "local_fallback",
    }

def analyze_logs_safely(log_data, system_prompt=None):
    """
    安全的日志分析入口
    尝试AI分析，失败则自动降级到规则分析
    """
    # 1. 尝试AI分析
    ai_result = analyze_with_ai(log_data, system_prompt)
    if ai_result is not None:
        return {"source": "ai", "analysis": ai_result}

    # 2. AI分析失败，使用降级方案
    structured = structured_fallback_from_log_text(str(log_data))
    fallback_result = structured.get("summary") or fallback_keyword_analysis(str(log_data))
    return {"source": "fallback", "analysis": fallback_result, "structured": structured}
