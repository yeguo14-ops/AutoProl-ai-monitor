# monitor/collector.py
"""
数据采集模块
功能：采集系统指标（CPU、内存、磁盘）、系统日志尾部，并调用 Java AI 服务 enrich。
"""
import datetime
import os
import sys
import time

import psutil
from dotenv import load_dotenv
from logger_config import setup_logger

from .ai_analyzer import structured_fallback_from_log_text
from ..repo.ai_java_client import analyze_log_via_java, get_cpu_dynamic_threshold
from ..repo.hostname import resolve_monitor_hostname
from ..repo.log_tail import collect_system_log_tail

load_dotenv()
sys.dont_write_bytecode = False
sys.pycache_prefix = "./cache/"
logger = setup_logger(__name__)


def _ai_enabled() -> bool:
    return os.getenv("JAVA_AI_SERVICE_ENABLED", "true").lower() in ("1", "true", "yes")


def _enrich_with_ai(data: dict) -> None:
    """就地写入 ai_log_analysis、cpu_dynamic_threshold、ai_analysis_source。"""
    hostname = resolve_monitor_hostname()
    log_tail = data.get("raw_syslog_tail") or ""

    data["cpu_dynamic_threshold"] = None
    data["ai_log_analysis"] = None
    data["ai_analysis_source"] = "none"

    if _ai_enabled():
        thr = get_cpu_dynamic_threshold(hostname)
        if thr is not None:
            data["cpu_dynamic_threshold"] = thr

    if not log_tail.strip():
        logger.debug("无系统日志文本，跳过 AI 日志分析")
        return

    if not _ai_enabled():
        fb = structured_fallback_from_log_text(log_tail)
        data["ai_log_analysis"] = fb
        data["ai_analysis_source"] = "local_fallback"
        return

    java_result = analyze_log_via_java(log_tail)
    if java_result is not None:
        if isinstance(java_result, dict) and "source" not in java_result:
            java_result = {**java_result, "source": "java"}
        data["ai_log_analysis"] = java_result
        data["ai_analysis_source"] = "java"
        logger.info("本轮采集已合并 Java AI 日志分析结果 (source=java)")
        return

    fb = structured_fallback_from_log_text(log_tail)
    data["ai_log_analysis"] = fb
    data["ai_analysis_source"] = "local_fallback"
    logger.warning("Java AI 不可用或返回异常，已使用本地关键词兜底分析")


def collect_system_metrics(max_retries=2, retry_delay=1):
    """
    采集系统指标与日志尾部，并尝试调用 Java AI（失败则本地兜底）。
    :return: 数据字典；失败返回 None
    """
    tail_lines = int(os.getenv("SYSLOG_TAIL_LINES", "80"))

    for attempt in range(max_retries + 1):
        try:
            disk_path = "/" if os.name != "nt" else os.getenv("MONITOR_DISK_PATH", "C:\\")
            data = {
                "time": datetime.datetime.now(),
                "cpu": psutil.cpu_percent(interval=1),
                "mem": psutil.virtual_memory().percent,
                "disk": psutil.disk_usage(disk_path).percent,
            }
            try:
                data["raw_syslog_tail"] = collect_system_log_tail(max_lines=tail_lines)
            except Exception as e:
                logger.warning("系统日志采集异常（继续指标采集）: %s", e)
                data["raw_syslog_tail"] = ""

            try:
                _enrich_with_ai(data)
            except Exception as e:
                logger.error("AI 增强阶段异常（不影响基础指标）: %s", e, exc_info=True)
                if data.get("raw_syslog_tail"):
                    data["ai_log_analysis"] = structured_fallback_from_log_text(data["raw_syslog_tail"])
                    data["ai_analysis_source"] = "local_fallback"

            logger.debug(
                "采集成功 (尝试 %s/%s): CPU=%s%% dyn_thr=%s ai=%s",
                attempt + 1,
                max_retries + 1,
                data["cpu"],
                data.get("cpu_dynamic_threshold"),
                data.get("ai_analysis_source"),
            )
            return data
        except Exception as e:
            if attempt < max_retries:
                logger.warning(
                    "采集失败 (尝试 %s/%s): %s，%s秒后重试...",
                    attempt + 1,
                    max_retries + 1,
                    e,
                    retry_delay,
                )
                time.sleep(retry_delay)
            else:
                logger.error("数据采集失败，已重试%s次: %s", max_retries, e, exc_info=True)
    return None
