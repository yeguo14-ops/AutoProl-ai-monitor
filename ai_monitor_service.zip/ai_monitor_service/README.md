# ai_monitor_service

基于 **Spring Boot 3.2 + Java 17 + Gradle** 的 AI 日志分析微服务。对外提供 REST 接口，将监控采集到的日志交给 **DeepSeek 大模型**做语义归类与风险判断，供监控系统前端/告警模块消费。

---

## 1. 系统架构

![ai_monitor_service 分层架构](ai_monitor_architecture.png)

### 分层说明（重构后）

| 层                  | 包路径                           | 类                                                     | 职责                            |
| ------------------ | ----------------------------- | ----------------------------------------------------- | ----------------------------- |
| **入口层 Controller** | `com.example.demo.controller` | `AIController`                                        | 对外 REST 接口，只做接收/转发，不写业务逻辑     |
| **业务层 Service**    | `com.example.demo.service`    | `DeepSeekService`                                     | 核心业务：调用 AI 平台、解析响应、结果缓存、错误兜底  |
| **模型层 model.dto**  | `com.example.demo.model.dto`  | `AiLogAnalysisRequest/Response`、`CpuBaselineResponse` | 接口入参/出参数据载体                   |
| **客户端 client**     | `com.example.demo.client`     | `DeepSeekRequest/Response`                            | DeepSeek 平台请求/响应结构            |
| **配置 config**      | `com.example.demo.config`     | `CacheSetupProbe`、`LogAnalysisCacheKeyGenerator`      | 缓存探测、SHA-256 缓存键生成            |
| **启动类**            | `com.example.demo`            | `DemoApplication`                                     | `@SpringBootApplication` 启动入口 |

> `@SpringBootApplication` 默认组件扫描 `com.example.demo` 及其全部子包，因此分包后所有 `@RestController`/`@Service`/`@Component` 仍能被自动装配，无需额外配置。

### 接口一览

| 方法   | 路径                               | 说明                                                                            |
| ---- | -------------------------------- | ----------------------------------------------------------------------------- |
| POST | `/api/ai/analyze/log`            | 日志语义分析（真实调用 DeepSeek），返回 `errorType / riskLevel / possibleCause / suggestion` |
| GET  | `/api/ai/baseline/cpu?hostname=` | CPU 动态基线（模拟数据：mean + 2*std）                                                   |

---

## 2. 技术要点

- **AI 调用**：`DeepSeekService` 通过 Spring WebFlux `WebClient` 发起 HTTPS 请求，`Mono` + `boundedElastic` 调度，避免阻塞 Servlet 线程。
- **结果缓存**：`@Cacheable` + Caffeine，缓存键用整条日志的 **SHA-256** 哈希（`LogAnalysisCacheKeyGenerator`），避免 hashCode 碰撞。
- **健壮性**：AI 返回非法 JSON / 调用失败 / 中文 errorType 时均有兜底降级，不中断主流程。
- **密钥安全**：DeepSeek API Key 通过环境变量（`deepseek.api.key`）注入，**不硬编码、不入库**，日志中对 Key 脱敏。

---

## 3. 构建与运行

```bash
# 本地构建（需 JDK 17）
./gradlew clean bootJar

# 直接运行
./gradlew bootRun

# 或打 jar 运行
java -jar build/libs/app.jar

# Docker 构建与运行（多阶段：gradle 构建 -> jre 运行）
docker build -t ai-monitor-service .
docker run -e DB_HOST=127.0.0.1 -e SPRING_DATASOURCE_PASSWORD=xxx -p 8080:8080 ai-monitor-service
```

> 运行所需环境变量（DeepSeek 配置）通过 application.properties / 环境变量注入，请勿提交真实密钥。

---

## 4. 目录结构

```
ai_monitor_service/
├── src/main/java/com/example/demo/
│   ├── DemoApplication.java            # 启动类
│   ├── controller/AIController.java     # REST 入口
│   ├── service/DeepSeekService.java     # 业务逻辑
│   ├── config/
│   │   ├── CacheSetupProbe.java
│   │   └── LogAnalysisCacheKeyGenerator.java
│   ├── model/dto/                       # 接口 DTO
│   │   ├── AiLogAnalysisRequest.java
│   │   ├── AiLogAnalysisResponse.java
│   │   └── CpuBaselineResponse.java
│   └── client/                          # DeepSeek 平台结构
│       ├── DeepSeekRequest.java
│       └── DeepSeekResponse.java
├── src/main/resources/application.properties
├── build.gradle / settings.gradle / gradlew
├── Dockerfile
└── ai_monitor_architecture.png          # 架构图
```
