# monitor/__init__.py
"""
监控系统核心模块包
- services: 业务逻辑层（采集、告警、调度、AI分析）
- repo:     数据访问层（存储、缓存、外部服务客户端）
"""

from .services.collector import collect_system_metrics
from .repo.storage import save_to_mysql, save_to_file
from .services.alerter import check_and_alert
from .services.scheduler import run_one_collection_cycle, main_loop
from .repo.redis_client import get_redis_client

__version__ = "1.0.0"
__all__ = [
    'collect_system_metrics',
    'save_to_mysql',
    'save_to_file',
    'check_and_alert',
    'run_one_collection_cycle',
    'main_loop',
    'get_redis_client',
]