package com.example.demo.config;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

/**
 * 使用整条日志内容的 SHA-256 十六进制串作为缓存键，避免仅用 hashCode 的碰撞与截断问题。
 */
@Component("logAnalysisKeyGenerator")
public class LogAnalysisCacheKeyGenerator implements KeyGenerator {

    @Override
    public Object generate(Object target, Method method, Object... params) {
        if (params.length == 0 || params[0] == null) {
            return "null";
        }
        byte[] input = params[0].toString().getBytes(StandardCharsets.UTF_8);
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(input);
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            return String.valueOf(params[0].hashCode());
        }
    }
}
