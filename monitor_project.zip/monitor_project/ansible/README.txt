Day 17-18 自动化部署（Ansible）

一、控制机准备
  pip install ansible
  cd monitor_project/ansible
  ansible-galaxy collection install -r requirements.yml

二、清单
  cp inventory.example.ini inventory.ini
  编辑 inventory.ini：目标 IP、ansible_user、私钥路径。

三、执行
  ansible-playbook -i inventory.ini deploy.yml

四、Playbook 做了什么
  1. 在目标 Ubuntu 上安装 Docker CE + docker compose 插件
  2. rsync 同步上一级目录（整个 monitor_project）到目标 /opt/monitor_platform
  3. 若无 .env，从 docker/defaults.compose.env 复制一份
  4. 在目标机执行: docker compose up -d --build

五、前置条件
  - 控制机能 SSH 到目标机，且 ansible_user 具备 sudo（无需密码或已配置 become）
  - 目标机为 Ubuntu（使用 Docker 官方 Ubuntu 源）；其他发行版需自行改安装任务
  - Java 镜像 ai-monitor-service:latest 已在目标机存在（docker load）或可 docker pull
  - 控制机已安装 rsync（synchronize 模块需要）

六、变量（可选）
  命令行：ansible-playbook -i inventory.ini deploy.yml -e deploy_path=/data/monitor

七、仅更新代码不重装 Docker
  可拆出 playbook 为多个 play；当前为一体化演示，重复执行会保留已装 Docker 仅同步代码并 compose up。
