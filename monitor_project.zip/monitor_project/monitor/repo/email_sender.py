# alert.py
import sys
import smtplib
from typing import Any, Dict, List, Optional
from email.mime.text import MIMEText
from email.header import Header
from email.utils import formataddr
import os
from dotenv import load_dotenv
from logger_config import setup_logger
 
sys.dont_write_bytecode= False
sys.pycache_prefix = "./cache/"

logger = setup_logger(__name__)  # 初始化本模块的logger

load_dotenv()


def _pick_ai_text(ai: dict, *keys: str) -> str:
    """从 Java 可能返回的多种字段名中取第一段非空文本。"""
    if not isinstance(ai, dict):
        return ""
    for k in keys:
        v = ai.get(k)
        if v is None:
            continue
        if isinstance(v, (list, tuple)):
            v = "；".join(str(x) for x in v if x is not None)
        s = str(v).strip()
        if s:
            return s
    return ""


def format_ai_enhanced_alert_body(
    *,
    hostname: str,
    occurred_at: str,
    metrics: Dict[str, Any],
    alert_bullets: List[str],
    alert_codes: List[str],
    cpu_threshold_effective: float,
    cpu_used_dynamic: bool,
    static_cpu_threshold: float,
    mem_threshold: float,
    disk_threshold: float,
    ai_analysis: Optional[Dict[str, Any]],
    ai_source: Optional[str],
    log_preview: Optional[str],
    max_log_preview: int = 2500,
) -> str:
    """
    生成「指标 + 动态阈值说明 + AI 日志结论」融合后的纯文本邮件正文。
    供 monitor.alerter 在触发告警时调用；send_alert 仍只负责 SMTP。
    """
    cpu = metrics.get("cpu")
    mem = metrics.get("mem")
    disk = metrics.get("disk")

    thr_cpu_note = (
        f"本次 CPU 比较采用：动态计算阈值 {cpu_threshold_effective}%（来自 Java 基线服务）。"
        if cpu_used_dynamic
        else f"本次 CPU 比较采用：静态环境阈值 {cpu_threshold_effective}%（环境变量 ALERT_THRESHOLD_CPU，当前 {static_cpu_threshold}%）。"
    )

    lines = [
        "【智能告警】服务器监控 — AI 增强报告",
        "",
        "一、核心告警",
        "以下条目为本次触发的告警要点（可能同时包含指标类与 AI 高风险日志类）：",
    ]
    for i, b in enumerate(alert_bullets, 1):
        lines.append(f"  {i}. {b}")
    lines.append("")

    lines.append("二、阈值与决策说明")
    lines.append(f"  · CPU：当前 {cpu}%，{thr_cpu_note}")
    lines.append(f"  · 内存：当前 {mem}%，比较阈值 {mem_threshold}%（静态）。")
    lines.append(f"  · 磁盘：当前 {disk}%，比较阈值 {disk_threshold}%（静态）。")
    lines.append("")

    lines.append("三、AI 日志分析报告（Java 服务）")
    if isinstance(ai_analysis, dict) and ai_analysis:
        et = ai_analysis.get("errorType") or ai_analysis.get("error_type") or "—"
        rl = ai_analysis.get("riskLevel") or ai_analysis.get("risk_level") or "—"
        sm = _pick_ai_text(
            ai_analysis,
            "summary",
            "message",
            "analysis",
            "description",
            "detail",
        )
        cause = _pick_ai_text(
            ai_analysis,
            "possibleCause",
            "rootCause",
            "cause",
            "reason",
        )
        suggest = _pick_ai_text(
            ai_analysis,
            "suggestion",
            "suggestions",
            "recommendation",
            "recommendations",
            "remediation",
            "action",
        )
        lines.append(f"  · 错误类型（errorType）：{et}")
        lines.append(f"  · 风险等级（riskLevel）：{rl}")
        lines.append(f"  · 分析摘要：{sm or '（接口未返回摘要字段）'}")
        if cause:
            lines.append(f"  · 可能原因：{cause}")
        if suggest:
            lines.append(f"  · 处理建议：{suggest}")
        lines.append(f"  · 数据来源：{ai_source or 'unknown'}")
    else:
        lines.append("  （本轮无结构化 AI 日志结论，或 Java 服务未返回 JSON 对象）")
    lines.append("")

    lines.append("四、上下文")
    lines.append(f"  · 主机名：{hostname}")
    lines.append(f"  · 告警时间：{occurred_at}")
    if alert_codes:
        lines.append(f"  · 告警类型标签：{', '.join(alert_codes)}")
    lines.append("")

    preview = (log_preview or "").strip()
    if preview:
        lines.append("五、关联系统日志摘要（本轮采集尾部，截断显示）")
        if len(preview) > max_log_preview:
            preview = preview[:max_log_preview] + "\n…（已截断）"
        lines.append(preview)
    else:
        lines.append("五、关联系统日志摘要")
        lines.append("  （本轮未采集到日志文本）")

    lines.append("")
    lines.append("— 本邮件由监控平台自动生成；请结合现场环境与变更记录进一步排查。")
    return "\n".join(lines)


def build_ai_alert_subject(hostname: str, occurred_at: str, alert_codes: List[str]) -> str:
    """根据是否含 AI 高风险日志，生成更易分拣的主题前缀。"""
    codes = alert_codes or []
    if "ai_log" in codes:
        return f"【服务器监控·含AI高风险日志】- {hostname} - {occurred_at}"
    if "cpu" in codes and any(c in codes for c in ("mem", "disk")):
        return f"【服务器监控·多指标】- {hostname} - {occurred_at}"
    return f"【服务器监控告警】- {hostname} - {occurred_at}"


def send_alert(subject, content):
    """
    通用的告警发送函数
    :param subject: 邮件主题
    :param content: 邮件正文
    """
    try:
        # 从环境变量读取SMTP配置
        smtp_server = os.getenv('SMTP_SERVER', "smtp.qq.com")
        smtp_port = int(os.getenv('SMTP_PORT', 465))
        sender = os.getenv('SENDER_EMAIL', "")
        password = os.getenv('SENDER_AUTH_CODE', "")
        receiver = os.getenv('RECEIVER_EMAIL', "")
        
        # 检查必要配置是否完整
        if not all([smtp_server, sender, password, receiver]):
            logger.error("邮件配置不完整，无法发送告警")
            logger.error(f"配置状态: SMTP服务器={bool(smtp_server)}, "
                        f"发件人={bool(sender)}, 授权码={'已设置' if password else '未设置'}, "
                        f"收件人={bool(receiver)}")
            return False
        
        logger.info(f"开始准备发送告警邮件: {subject}")
        
        # 创建邮件内容
        msg = MIMEText(content, 'plain', 'utf-8')
        # 使用formataddr正确处理发件人和收件人名称
        msg['From'] = formataddr(('监控系统', sender))
        msg['To'] = formataddr(('管理员', receiver))
        # 修复：使用formataddr或直接赋值，而不是Header
        msg['Subject'] = f"监控告警: {subject}"
        
        # 连接SMTP服务器并发送
        logger.debug(f"连接SMTP服务器: {smtp_server}:{smtp_port}")
        server = smtplib.SMTP_SSL(smtp_server, smtp_port, timeout=10)
        
        logger.debug("进行SMTP身份验证...")
        server.login(sender, password)
        
        logger.debug("发送邮件内容...")
        server.sendmail(sender, [receiver], msg.as_string())
        
        server.quit()
        logger.info(f"告警邮件发送成功: {subject}")
        logger.debug(f"邮件已发送至: {receiver}")
        
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        logger.error(f"SMTP身份验证失败: {e}")
        logger.error("请检查: 1) 发件邮箱是否正确 2) SMTP授权码是否有效 3) 是否开启SMTP服务")
        return False
        
    except smtplib.SMTPConnectError as e:
        logger.error(f"连接SMTP服务器失败: {e}")
        logger.error(f"请检查网络连接和SMTP服务器地址: {smtp_server}:{smtp_port}")
        return False
        
    except smtplib.SMTPException as e:
        logger.error(f"SMTP协议错误: {e}")
        return False
        
    except Exception as e:
        logger.exception(f"发送告警邮件时发生未知错误: {e}")
        return False
