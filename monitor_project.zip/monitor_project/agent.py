﻿#!/usr/bin/env python3
"""
agent.py - 运行在被控端，定时采集系统指标并推送到控制服务器（Windows/Linux通用）
"""
import psutil
import requests
import time
import json
import os
import sys
import tempfile
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from monitor.repo.hostname import is_docker_container_id, resolve_monitor_hostname

# 从环境变量读取控制服务器地址，默认本地
CONTROL_SERVER = os.getenv('CONTROL_SERVER', 'http://localhost:5000/api/report')
INTERVAL = int(os.getenv('COLLECT_INTERVAL', '60'))  # 采集间隔秒数
# 跨平台获取系统盘路径：Windows取C盘，Linux取根目录
SYSTEM_DISK = 'C:\\' if os.name == 'nt' else '/'

def collect_metrics():
    """采集系统指标"""
    return {
        "host_name": resolve_monitor_hostname(),
        "cpu_percent": psutil.cpu_percent(interval=1),
        "mem_percent": psutil.virtual_memory().percent,
        "disk_usage": psutil.disk_usage(SYSTEM_DISK).percent,
        "collect_time": datetime.now().isoformat()
    }

def push_metrics(data):
    """推送数据到控制服务器"""
    try:
        resp = requests.post(CONTROL_SERVER, json=data, timeout=10)
        resp.raise_for_status()
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 推送成功: {data['host_name']}")
        return True
    except Exception as e:
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 推送失败: {e}")
        # 降级：写入跨平台临时目录，稍后重试
        backup_file = os.path.join(tempfile.gettempdir(), f"monitor_backup_{resolve_monitor_hostname()}.jsonl")
        with open(backup_file, "a") as f:
            f.write(json.dumps(data) + "\n")
        return False

def main():
    host = resolve_monitor_hostname()
    if is_docker_container_id(host):
        print(
            f"错误: 主机名为 Docker 容器 ID ({host})，请在宿主机运行 agent 并设置 "
            "MONITOR_HOST_NAME=真实主机名，勿将 agent 打包进容器。"
        )
        sys.exit(1)
    print(f"Agent 启动，主机名: {host}，目标: {CONTROL_SERVER}，间隔: {INTERVAL}秒")
    while True:
        data = collect_metrics()
        push_metrics(data)
        time.sleep(INTERVAL)

if __name__ == "__main__":
    main()
