# monitor/ai_java_client.py
"""
调用 Java AI 微服务的 HTTP 客户端：日志分析、动态 CPU 基线。
不可用时记录日志并返回 None，由调用方做本地关键词兜底。
"""

import os
from typing import Any, Dict, Optional
from urllib.parse import urlparse, urlunparse

import requests
from dotenv import load_dotenv
from logger_config import setup_logger

load_dotenv()
logger = setup_logger(__name__)

_startup_url_logged = False


def get_resolved_ai_base_url() -> str:
    """当前环境解析后的 Java AI 根地址（无尾斜杠），与 HTTP 请求实际使用的一致。"""
    raw = (os.getenv("AI_SERVICE_BASE_URL") or "").strip()
    if not raw:
        raw = "http://127.0.0.1:8080"
    return raw.rstrip("/")


def _format_ai_base_url_for_log() -> str:
    """打印用字符串；AI_SERVICE_BASE_URL_LOG_MASKED=true 时对主机名与 URL 内账号做脱敏。"""
    url = get_resolved_ai_base_url()
    masked = os.getenv("AI_SERVICE_BASE_URL_LOG_MASKED", "").lower() in ("1", "true", "yes")
    if not masked:
        return url
    try:
        p = urlparse(url)
        userinfo = ""
        if p.username or p.password:
            userinfo = "***:***@"
        port = p.port
        host = "[redacted-host]"
        netloc = f"{userinfo}{host}:{port}" if port else f"{userinfo}{host}"
        return urlunparse((p.scheme or "http", netloc, p.path or "", "", "", ""))
    except Exception:
        return "<AI_SERVICE_BASE_URL unparseable, masked>"


def log_ai_service_url_at_startup() -> None:
    """
    进程内仅记录一次 INFO：解析后的 AI 基址（可选脱敏）、HTTP 开关、loopback 提示。
    应在 load_dotenv() 之后调用（main.py / collect.py / scheduler 入口）。
    """
    global _startup_url_logged
    if _startup_url_logged:
        return
    _startup_url_logged = True

    display = _format_ai_base_url_for_log()
    http_on = os.getenv("JAVA_AI_SERVICE_ENABLED", "true").lower() in ("1", "true", "yes")
    http_flag = "开启" if http_on else "关闭"

    host = (urlparse(get_resolved_ai_base_url()).hostname or "").lower()
    loopback = host in ("localhost", "127.0.0.1", "::1")
    hint = ""
    if loopback:
        hint = (
            " | 提示: 当前为 loopback，仅当 Spring Boot 与本进程同机且监听该端口时适用；"
            "若 Java 在其它主机/容器网络名不同，请改为可达 IP 或主机名"
        )

    logger.info(
        "Java AI 服务基址(解析后): %s | 调用 Java HTTP: %s%s",
        display,
        http_flag,
        hint,
    )


def _base_url() -> str:
    return get_resolved_ai_base_url()


def _post_field() -> str:
    return os.getenv("AI_LOG_POST_FIELD", "log")


def _http_timeout() -> float:
    return float(os.getenv("AI_HTTP_TIMEOUT_SECONDS", "15"))


def _proxies_for_java_http():
    """
    默认绕过环境变量中的 http(s)_proxy，避免虚拟机为「上外网」设的代理误伤本机 Java。
    若必须经企业代理访问 Java，设置 JAVA_AI_IGNORE_ENV_PROXY=false。
    """
    if os.getenv("JAVA_AI_IGNORE_ENV_PROXY", "true").lower() in ("0", "false", "no"):
        return None
    return {"http": None, "https": None}


def analyze_log_via_java(log_text: str) -> Optional[Dict[str, Any]]:
    """
    POST {base}/api/ai/analyze/log
    请求体默认: {"log": "<原始文本>"}，字段名可通过 AI_LOG_POST_FIELD 配置与 Java 对齐。
    返回解析后的 JSON 字典；失败返回 None。
    """
    text = (log_text or "").strip()
    if not text:
        return None
    url = f"{_base_url()}/api/ai/analyze/log"
    field = _post_field()
    payload = {field: text}
    try:
        resp = requests.post(
            url,
            json=payload,
            timeout=_http_timeout(),
            proxies=_proxies_for_java_http(),
        )
        resp.raise_for_status()
        body = resp.json()
        if isinstance(body, dict):
            logger.info(
                "Java AI 日志分析成功: %s",
                {k: body.get(k) for k in ("errorType", "riskLevel", "summary") if k in body},
            )
            return body
        logger.warning("Java AI 日志分析返回非 JSON 对象，已忽略: type=%s", type(body).__name__)
        return None
    except requests.RequestException as e:
        logger.error("Java AI 日志分析请求失败（将使用本地兜底）: %s", e)
        return None
    except ValueError as e:
        logger.error("Java AI 日志分析响应非 JSON: %s", e)
        return None


def get_cpu_dynamic_threshold(hostname: str) -> Optional[float]:
    """
    GET {base}/api/ai/baseline/cpu?hostname=xxx
    兼容多种 JSON 形态: {"threshold":85} / {"cpuThreshold":85} / {"value":85} / 纯数字。
    """
    hn = (hostname or "").strip() or "localhost"
    url = f"{_base_url()}/api/ai/baseline/cpu"
    try:
        resp = requests.get(
            url,
            params={"hostname": hn},
            timeout=_http_timeout(),
            proxies=_proxies_for_java_http(),
        )
        resp.raise_for_status()
        try:
            data = resp.json()
        except ValueError:
            raw = resp.text.strip()
            try:
                v = float(raw)
                logger.info("Java AI 动态 CPU 阈值(纯文本): hostname=%s threshold=%s", hn, v)
                return v
            except ValueError:
                logger.warning("Java AI 动态阈值响应无法解析为 JSON 或数字: %s", raw[:200])
                return None
        if isinstance(data, (int, float)):
            v = float(data)
            logger.info("Java AI 动态 CPU 阈值: hostname=%s threshold=%s", hn, v)
            return v
        if not isinstance(data, dict):
            return None
        for key in (
            "dynamicThreshold",
            "dynamic_threshold",
            "threshold",
            "cpuThreshold",
            "cpu_threshold",
            "value",
            "baseline",
        ):
            if key in data and data[key] is not None:
                v = float(data[key])
                logger.info("Java AI 动态 CPU 阈值: hostname=%s threshold=%s (field=%s)", hn, v, key)
                return v
        logger.warning("Java AI 动态阈值 JSON 中未找到可解析的阈值字段: keys=%s", list(data.keys()))
        return None
    except requests.RequestException as e:
        logger.error("Java AI 动态 CPU 阈值请求失败: %s", e)
        return None
    except (TypeError, ValueError) as e:
        logger.error("Java AI 动态 CPU 阈值解析失败: %s", e)
        return None
