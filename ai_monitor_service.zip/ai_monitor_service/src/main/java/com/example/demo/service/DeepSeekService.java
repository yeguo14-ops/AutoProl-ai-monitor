package com.example.demo.service;

import com.example.demo.model.dto.AiLogAnalysisResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import jakarta.annotation.PostConstruct;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Locale;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DeepSeekService {

    // 1. 常量定义 (避免魔法字符串)
    /**
     * errorType 要求英文机器可读标识，避免「构建测试错误」等自然语言被误认为系统异常；
     * possibleCause / suggestion 用中文便于运维阅读。
     */
    private static final String SYSTEM_PROMPT = """
            你是资深运维专家。根据用户给出的日志行，只做归类与建议。
            必须只输出一行合法 JSON 对象，不要 Markdown、不要代码围栏、不要多余文字。
            字段与取值约定（违反则视为不合格输出）：
            - errorType：英文 PascalCase 或 UpperCamelCase 的机器标识，表示「日志语义上的事件类型」，
              例如 BuildTestFailure、DatabaseConnectionTimeout、UnknownNoise。禁止自然语言句子或中文。
            - riskLevel：只能是 HIGH、MEDIUM、LOW 三个英文大写单词之一。
            - possibleCause：中文，简要说明可能原因。
            - suggestion：中文，可执行的排查或优化建议。
            JSON 模板：{"errorType":"","riskLevel":"","possibleCause":"","suggestion":""}
            """;
    private static final String DEFAULT_RISK_LEVEL = "MEDIUM";
    private static final String CONTENT_TYPE_HEADER = "Content-Type";
    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String JSON_PARSE_ERROR_MSG = "JSON解析失败";

    // 2. 配置属性 (使用 setter 注入，解决空指针问题)
    private String apiUrl;
    private String apiKey;
    private String model;

    // 3. 依赖组件
    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // 4. 构造函数只接收 WebClient.Builder
    public DeepSeekService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    // 5. Setter 注入配置 (关键修改点：确保配置能正确注入)
    @Value("${deepseek.api.url}")
    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    @Value("${deepseek.api.key}")
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    @Value("${deepseek.api.model}")
    public void setModel(String model) {
        this.model = model;
    }

    @PostConstruct
    public void init() {
        System.out.println("=== 配置注入确认 ===");
        System.out.println("apiUrl: " + apiUrl);
        System.out.println("apiKey: " + maskApiKey(apiKey));
        System.out.println("model: " + model);
    }

    /**
     * AI 日志分析（结果缓存：键由 {@link LogAnalysisCacheKeyGenerator} 基于日志全文哈希生成）。
     * 使用同步阻塞以配合 {@link Cacheable}；控制器侧在 boundedElastic 上调用，避免占满 Servlet 线程。
     */
    @Cacheable(value = "logAnalysisCache", keyGenerator = "logAnalysisKeyGenerator")
    public AiLogAnalysisResponse analyzeLogWithDeepSeek(String logText) {
        System.out.println("🚀 开始调用真实 DeepSeek API...");

        Map<String, Object> requestBody = buildRequestBody(logText);

        return callDeepSeekApi(requestBody)
                .map(this::processApiResponse)
                .onErrorResume(this::handleApiError)
                .block(Duration.ofMinutes(2));
    }

    /**
     * 构建请求体
     */
    private Map<String, Object> buildRequestBody(String logText) {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);

        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(Map.of("role", "system", "content", SYSTEM_PROMPT));
        messages.add(Map.of("role", "user", "content", "请分析日志：" + logText));

        requestBody.put("messages", messages);
        requestBody.put("temperature", 0.1);
        return requestBody;
    }

    /**
     * 发起 API 请求
     */
    private Mono<String> callDeepSeekApi(Map<String, Object> requestBody) {
        // 【关键修复】手动拼接 URL，并打印出来检查
        String fullUrl = apiUrl;
        System.out.println("🌐 请求目标 URL: " + fullUrl);

        return webClient.post()
                .uri(fullUrl) // 使用完整的 URL
                .header(AUTHORIZATION_HEADER, "Bearer " + apiKey)
                .header(CONTENT_TYPE_HEADER, "application/json")
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(String.class);
    }

    /**
     * 处理 API 响应
     */
    private AiLogAnalysisResponse processApiResponse(String responseBody) {
        System.out.println("✅ 收到 DeepSeek 原始响应");
        System.out.println("原始数据: " + responseBody);

        String content = extractContentFromResponse(responseBody);

        try {
            // 尝试解析 AI 返回的 JSON
            JsonNode rootNode = objectMapper.readTree(content);
            AiLogAnalysisResponse result = new AiLogAnalysisResponse();

            String rawErrorType = getJsonValue(rootNode, "errorType", "Uncategorized");
            String possibleCause = getJsonValue(rootNode, "possibleCause", "AI分析结果");
            if (containsCjk(rawErrorType)) {
                System.out.println("提示: 模型将 errorType 写成了自然语言，已改为 GenericLogInsight，原文并入 possibleCause 前缀。");
                possibleCause = "【模型原始归类】" + rawErrorType + "。" + possibleCause;
                rawErrorType = "GenericLogInsight";
            }
            result.setErrorType(trimErrorTypeCode(rawErrorType));
            result.setRiskLevel(normalizeRiskLevel(getJsonValue(rootNode, "riskLevel", DEFAULT_RISK_LEVEL)));
            result.setPossibleCause(possibleCause);
            result.setSuggestion(getJsonValue(rootNode, "suggestion", "请查看原始响应"));

            return result;
        } catch (Exception e) {
            System.err.println("⚠️ " + JSON_PARSE_ERROR_MSG + ": " + e.getMessage());
            // 解析失败时，返回包含原始内容的兜底响应
            return createFallbackWithAiContent(content, e.getMessage());
        }
    }

    /**
     * 提取内容
     */
    private String extractContentFromResponse(String response) {
        try {
            JsonNode rootNode = objectMapper.readTree(response);
            JsonNode choicesNode = rootNode.path("choices");
            if (choicesNode.isArray() && choicesNode.size() > 0) {
                JsonNode messageNode = choicesNode.get(0).path("message");
                return messageNode.path("content").asText();
            }
        } catch (Exception e) {
            System.err.println("⚠️ 响应解析失败: " + e.getMessage());
        }
        return response;
    }

    // --- 辅助方法 ---

    private String getJsonValue(JsonNode node, String field, String defaultValue) {
        return node.has(field) ? node.get(field).asText() : defaultValue;
    }

    private static boolean containsCjk(String s) {
        if (s == null || s.isEmpty()) {
            return false;
        }
        return s.codePoints().anyMatch(cp -> Character.UnicodeScript.of(cp) == Character.UnicodeScript.HAN);
    }

    /** 仅保留适合作为 API 标识的 errorType，过长则截断。 */
    private static String trimErrorTypeCode(String raw) {
        if (raw == null || raw.isBlank()) {
            return "Uncategorized";
        }
        String t = raw.trim().replaceAll("\\s+", "");
        return t.length() > 80 ? t.substring(0, 80) : t;
    }

    /** 统一为 HIGH / MEDIUM / LOW，兼容模型偶发输出中文。 */
    private static String normalizeRiskLevel(String raw) {
        if (raw == null || raw.isBlank()) {
            return DEFAULT_RISK_LEVEL;
        }
        String u = raw.trim().toUpperCase(Locale.ROOT);
        if (u.equals("HIGH") || raw.contains("高")) {
            return "HIGH";
        }
        if (u.equals("MEDIUM") || u.equals("MID") || u.equals("中") || raw.contains("中")) {
            return "MEDIUM";
        }
        if (u.equals("LOW") || raw.contains("低")) {
            return "LOW";
        }
        return DEFAULT_RISK_LEVEL;
    }

    private AiLogAnalysisResponse createFallbackWithAiContent(String aiContent, String errorMessage) {
        AiLogAnalysisResponse response = new AiLogAnalysisResponse();
        response.setErrorType("JsonParseFailure");
        response.setRiskLevel(DEFAULT_RISK_LEVEL);
        response.setPossibleCause("AI 返回内容无法解析为 JSON：" + errorMessage);
        response.setSuggestion("AI 原始回复片段：" + aiContent);
        return response;
    }

    private Mono<AiLogAnalysisResponse> handleApiError(Throwable error) {
        if (error instanceof WebClientResponseException) {
            WebClientResponseException ex = (WebClientResponseException) error;
            System.err.println("❌ API 调用失败: " + ex.getStatusCode());
            return Mono.just(getFallbackResponse("API错误: " + ex.getStatusCode()));
        } else {
            // 打印详细的堆栈信息，方便排查空指针等问题
            error.printStackTrace();
            return Mono.just(getFallbackResponse("客户端错误: " + error.getMessage()));
        }
    }

    private AiLogAnalysisResponse getFallbackResponse(String reason) {
        AiLogAnalysisResponse response = new AiLogAnalysisResponse();
        response.setErrorType("DeepSeekInvocationFailure");
        response.setRiskLevel(DEFAULT_RISK_LEVEL);
        response.setPossibleCause("调用 DeepSeek 失败：" + reason);
        response.setSuggestion("请检查 API Key、网络与配额后重试。");
        return response;
    }

    private String maskApiKey(String key) {
        if (key == null || key.length() <= 8)
            return "****";
        return "****" + key.substring(key.length() - 4);
    }
}