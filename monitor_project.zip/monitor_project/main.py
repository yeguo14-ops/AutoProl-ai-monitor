﻿#!/usr/bin/env python3
# main.py
"""
监控系统主入口
替代原来的 collect.py
"""

import sys
import os

# 添加当前目录到Python路径，确保能导入各个模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
from monitor.repo.ai_java_client import log_ai_service_url_at_startup
from monitor.services.scheduler import main_loop

def main():
    """主函数"""
    # 加载环境变量
    load_dotenv()
    log_ai_service_url_at_startup()

    print("=" * 50)
    print("🚀 启动服务器监控系统")
    print("=" * 50)
    print(f"Python版本: {sys.version}")
    print(f"工作目录: {os.getcwd()}")
    print("=" * 50)
    
    try:
        # 启动主循环
        main_loop()
    except KeyboardInterrupt:
        print("\n🛑 监控系统已安全退出")
    except Exception as e:
        print(f"❌ 监控系统启动失败: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
